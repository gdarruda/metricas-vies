package net.sf.cb2java.types;

import net.sf.cb2java.data.Data;

import java.math.BigInteger;
import java.util.HashMap;

/**
 * Created by leandro on 5/28/16.
 */
public class Occurs
{
  private int occurs;
  private String dependsOn;

  public Occurs(int occurs)
  {
    this.occurs = occurs;
  }

  public Occurs(int occurs, String dependsOn)
  {
    this.occurs = occurs;
    this.dependsOn = dependsOn;
  }

  public int getOccurrencies()
  {
    return occurs;
  }

  public int getOccurrencies(HashMap<String, Data> dependencies)
  {
    if (this.dependsOn != null)
    {
      Data data = dependencies.get(this.dependsOn);

      if (data != null)
      {
        return ((BigInteger)data.getValue()).intValue();
      }
    }

    return occurs;
  }
}
