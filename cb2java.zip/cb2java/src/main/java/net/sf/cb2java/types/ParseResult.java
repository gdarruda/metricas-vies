package net.sf.cb2java.types;

import net.sf.cb2java.data.Data;

/**
 * Created by leandro on 5/29/16.
 */
public class ParseResult
{
    private Data data;
    private int read;

  public ParseResult(Data data, int read)
  {
    this.data = data;
    this.read = read;
  }

  public Data getData() {
    return data;
  }

  public int getRead() {
    return read;
  }



}
