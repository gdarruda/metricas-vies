package net.sf.cb2java;

import net.sf.cb2java.copybook.Copybook;
import net.sf.cb2java.copybook.CopybookParser;
import net.sf.cb2java.data.Record;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 * Created by leandro on 5/27/16.
 */
public class Main {
  public static void main(String[] args) throws IOException {

    String copyBook = "/Users/leandro/w/github/cb2java/src/test/resources/Data/copybooks/CUSDATCC";
    String data = "/Users/leandro/w/github/cb2java/src/test/resources/Data/mf-files/ZOS.FCUSTDAT.bin";

    //String copyBook = "/Users/leandro/w/github/cb2java/src/test/resources/test.copybook";
    //String data = "/Users/leandro/w/github/cb2java/src/test/resources/test.data";


    FileInputStream cpIs = new FileInputStream(copyBook);
    FileInputStream dataStream  = new FileInputStream(data);

    final Copybook cp = CopybookParser.parse("customer-data", cpIs);
    cp.setEncoding("Cp1047");
    List<Record> records = cp.parseData(dataStream);

    for (Record record : records) {
      System.out.println(record);
    }
  }
}
